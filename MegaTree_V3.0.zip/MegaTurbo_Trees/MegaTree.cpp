# include "MegaTree.h"


MegaTree_withmaxdepth::MegaTree_withmaxdepth() {
    maxDepth = 8;
    binth = 8;
}


MegaTree_withmaxdepth::MegaTree_withmaxdepth(int md, int b) {
    maxDepth = md;
    binth = b;
}


void MegaTree_withmaxdepth::ConstructClassifier(const vector<Rule> &rules) {
    vector<Rule> r = rules;
    vector<Rule> tmp;
    while (!r.empty()) {
        cout << roots.size() << "#";
        roots.push_back(ConstructMegaTree(ref(r), ref(tmp)));
        roots.back()->rules = r;
        roots.back()->nRules = r.size();
        r = move(tmp);
        cout << "\t" << roots.back()->nRules << "\t" << r.size() << endl;
    }
    cout << "\troots size:" << roots.size() << endl;
}


int MegaTree_withmaxdepth::ClassifyAPacket(const Packet &packet) {
    for (MTnode_withmaxdepth *root : roots) {
        MTnode_withmaxdepth *node = root;
        while (node && !node->isLeaf) {
            if (packet[node->dim] <= node->threshold) {
                node = node->children[0];
            } else {
                node = node->children[1];
            }
        }

        if (!node) {
            continue;
        }
        for (Rule &r : node->rules) {
            if (r.MatchesPacket(ref(packet))) {
                return r.priority; 
            }
        }
    }
    return -1; 
}


int MegaTree_withmaxdepth::ClassifyAPacket(const Packet &packet, uint64_t &Query) {
    Query = 1; // Simple query count for compatibility
    return ClassifyAPacket(packet);
}


// helper: find the leaf where a rule should reside in this tree; return nullptr if rule spans a split or path is broken
static MTnode_withmaxdepth* FindLeafForRule(MTnode_withmaxdepth* root, const Rule& rule) {
    MTnode_withmaxdepth* node = root;
    while (node && !node->isLeaf) {
        uint32_t d = node->dim;
        uint32_t thr = node->threshold;
        uint32_t low = rule.range[d][LowDim];
        uint32_t high = rule.range[d][HighDim];

        // rule spans the split: this tree cannot uniquely contain it
        if (low <= thr && high > thr) return nullptr;

        // go left or right
        if (high <= thr) {
            node = node->children[0];
        } else {
            node = node->children[1];
        }
    }
    return node;
}

Memory MegaTree_withmaxdepth::MemSizeBytes() const {
    Memory memoryUsage = 0;
    memoryUsage = sizeof(MegaTree_withmaxdepth);
    
    for (auto tree : roots) {
        memoryUsage += calculateNodeMemory(tree);
    }

    return memoryUsage;

}


Memory MegaTree_withmaxdepth::calculateNodeMemory(const MTnode_withmaxdepth* node) const {
    if (!node) return 0;
    
    size_t size = sizeof(MTnode_withmaxdepth);
    size += node->rules.size() * sizeof(Rule);

    for (auto child : node->children) {
        size += calculateNodeMemory(child);
    }
    
    return size;
}


int MegaTree_withmaxdepth::MemoryAccess() const {

    return 0;
}

size_t MegaTree_withmaxdepth::NumTables() const {
    
    return roots.size();
}

size_t MegaTree_withmaxdepth::RulesInTable(size_t tableIndex) const {

    return 0;
}

// Constrcut HyperSplit Tree based rules, return the root node, and put the rest duplicated rules into res
MTnode_withmaxdepth* MegaTree_withmaxdepth::ConstructMegaTree(const vector<Rule> &rules, vector<Rule> &res) {
    MTnode_withmaxdepth *root = new MTnode_withmaxdepth(ref(rules));
    queue<MTnode_withmaxdepth*> que;
    que.push(root);

    int leafCounter = 0; 

    while (!que.empty()) {
        MTnode_withmaxdepth *node = que.front();
        que.pop();

        // Check whether the maximum depth is reached
        if (node->depth >= maxDepth -1) {
            // If number of rules exceeds binth, move extras out
            while (node->rules.size() > binth) {
                res.push_back(node->rules.back());
                node->rules.pop_back();
            }
            node->nRules = node->rules.size();
            node->isLeaf = true;
            node->leafIndex = leafCounter++;
            continue;
        }

        // Select different segmeng point
        vector<vector<uint32_t> > diffSegpt(MAXDIMENSIONS);
        vector<vector<uint32_t> > segPoint(MAXDIMENSIONS, vector<uint32_t>(2 * rules.size(), 0));
        for (int d = 0; d < MAXDIMENSIONS; d ++) { 
            // Select all segPoint
            for (int i = 0; i < node->rules.size(); i ++) {
                segPoint[d][2 * i] = node->rules[i].range[d][LowDim];
                segPoint[d][2 * i + 1] = node->rules[i].range[d][HighDim]; 
            }
            sort(segPoint[d].begin(), segPoint[d].end());

            // Select distinct segPoint
            diffSegpt[d].push_back(segPoint[d][0]);
            for (int i = 1; i < segPoint[d].size(); i ++) {
                if (segPoint[d][i] != diffSegpt[d].back()) {
                    diffSegpt[d].push_back(segPoint[d][i]);
                }
            }
        }

        // Construct Monotonic stack(Maybe not)
        vector<vector<uint32_t> > dp(MAXDIMENSIONS);
        vector<vector<uint32_t> > kickRules(MAXDIMENSIONS);
        for (int d = 0; d < MAXDIMENSIONS; d ++) {
            dp[d].resize(diffSegpt[d].size());
            kickRules[d].resize(diffSegpt[d].size());
        }
        for (const Rule &r : node->rules) {
            for (int d = 0; d < MAXDIMENSIONS; d ++) {
                int lowIndex = lower_bound(diffSegpt[d].begin(), diffSegpt[d].end(),  r.range[d][LowDim]) - diffSegpt[d].begin();
                int highIndex = lower_bound(diffSegpt[d].begin(), diffSegpt[d].end(), r.range[d][HighDim]) - diffSegpt[d].begin();
                if (r.range[d][LowDim] != diffSegpt[d][lowIndex]) {
                    cout << "Low not exits" << endl;
                    cout << "dim: " << d << "\trule:" << r.id << "\t" << r.range[d][LowDim] << "\t" << diffSegpt[d][lowIndex] << endl; 
                    exit(-1);
                }
                if (r.range[d][HighDim] != diffSegpt[d][highIndex]) {
                    cout << "High not exits" << endl;
                    cout << "dim: " << d << "\trule:" << r.id << "\t" << r.range[d][HighDim] << "\t" << diffSegpt[d][highIndex] << endl; 
                    exit(-1);
                }
                dp[d][highIndex] ++;
                kickRules[d][lowIndex] ++;
                kickRules[d][highIndex] --;
            }            
        }

        // Select dim & thre
        uint32_t dim = 0, thre = 0, maxSegment = 0;
        for (int d = 0; d < MAXDIMENSIONS; d ++) {
            int nLeftRules = 0, nRightRules = 0, nKickRules = 0;
            for (int i = 0; i < diffSegpt[d].size(); i ++) {
                nLeftRules += dp[d][i];
                nKickRules += kickRules[d][i];
                nRightRules = node->rules.size() - nLeftRules - nKickRules;
                int t = min(nLeftRules, nRightRules);
                if (t > maxSegment) {
                    maxSegment = t;
                    dim = d;
                    thre = diffSegpt[d][i];
                }
            }
        }

        // Cannot segment any more
        if (maxSegment == 0) {
            // First, move out excessive rules beyond threshold
            while (node->rules.size() > binth) {
                res.push_back(node->rules.back());
                node->rules.pop_back();
            }
            node->nRules = node->rules.size();

            // Not at max depth yet, keep pushing down as single-branch
            node->dim = 0;   // choose any dimension, here the first
            node->threshold = UINT32_MAX;  // equivalent to always go left
            
            // Create single-branch: only create left child and push rules down
            vector<Rule> leftRules;
            for (Rule &r : node->rules) {
                leftRules.push_back(r);
            }
            
            node->rules.clear();
            node->children[0] = new MTnode_withmaxdepth(move(leftRules));
            node->children[0]->depth = node->depth + 1;
            que.push(node->children[0]);                               

            continue;
        }

        // Split into children
        node->dim = dim;
        node->threshold = thre;
        vector<Rule> leftRules, rightRules;

        int nKicked = 0;
        for (Rule &r : node->rules) {
            if (r.range[dim][LowDim] <= thre && r.range[dim][HighDim] > thre) {
                res.push_back(r);
                nKicked ++;
            } else if (r.range[dim][HighDim] <= thre) {
                leftRules.push_back(r);
            } else {
                rightRules.push_back(r);
            }
        }

        node->rules.clear();
        if (!leftRules.empty()) {
            node->children[0] = new MTnode_withmaxdepth(move(leftRules));
            node->children[0]->depth = node->depth + 1;
            que.push(node->children[0]);
        }

        if (!rightRules.empty()) {
            node->children[1] = new MTnode_withmaxdepth(move(rightRules));
            node->children[1]->depth = node->depth + 1;
            que.push(node->children[1]);
        }
    }
    return root;
}





// Function to output layered information
void MegaTree_withmaxdepth::OutputTreeLayers() {
    if (roots.empty()) return;
    // Traverse all trees and create a separate folder for each
    for (int treeIndex = 0; treeIndex < roots.size(); treeIndex++) {
        MTnode_withmaxdepth* root = roots[treeIndex];
        
        // Create a separate folder for each tree
        string treeFolder = "trees_" + to_string(treeIndex);
        system(("mkdir -p " + treeFolder).c_str());
        
        // Level-order traversal and re-index nodes within each layer
        queue<pair<MTnode_withmaxdepth*, int>> que; // pair<node, layer>
        que.push({root, 0});
        
        map<int, vector<MTnode_withmaxdepth*>> layerNodes; // layer -> nodes
        map<MTnode_withmaxdepth*, int> nodeToLayerId; // node -> index in layer
        
        // First pass: collect nodes in each layer
        while (!que.empty()) {
            auto [node, layer] = que.front();
            que.pop();
            if (!node) continue;
            
            // Record current layer nodes
            layerNodes[layer].push_back(node);
            // Push children into queue
            if (!node->isLeaf) {
                if (node->children[0]) {
                    que.push({node->children[0], layer + 1});
                }
                // Only non-single-fork nodes may have right child
                if (node->children[1]) {
                    que.push({node->children[1], layer + 1});
                }
            }
        }
        
        // Assign indices within each layer
        for (auto& [layer, nodes] : layerNodes) {
            for (int i = 0; i < nodes.size(); i++) {
                nodeToLayerId[nodes[i]] = i;
            }
        }
        
        // Output each layer to file
        for (const auto& [layer, nodes] : layerNodes) {
            // Check whether all nodes in this layer are leaves
            bool allLeaf = true;
            for (MTnode_withmaxdepth* node : nodes) {
                if (!node->isLeaf) {
                    allLeaf = false;
                    break;
                }
            }
            
            // Skip output if the layer only contains leaf nodes
            if (allLeaf) {
                continue;
            }
            
            string filename = treeFolder + "/" + to_string(layer) + ".txt";
            ofstream outFile(filename);
            if (outFile.is_open()) {
                // First line: number of nodes
                outFile << nodes.size() << endl;
                // Following lines: node index, left child index, selected field, threshold
                for (int i = 0; i < nodes.size(); i++) {
                    MTnode_withmaxdepth* node = nodes[i];
                    if (!node->isLeaf) {
                        // Compute child index in the next layer
                        int leftChildStart = -1;
                        int rightChildStart = -1;
                        
                        if (node->children[0]) {
                            leftChildStart = nodeToLayerId[node->children[0]];
                        }
                        outFile << i << " " << leftChildStart << " " << node->dim + 1 << " " << node->threshold << endl;  
                    }
                }
                outFile.close();
            }
        }
        // Output leaf node rules to the folder of the current tree
        OutputLeafNodes(layerNodes, nodeToLayerId, treeIndex);
    }
}


// Function to output leaf node rules
void MegaTree_withmaxdepth::OutputLeafNodes(const map<int, vector<MTnode_withmaxdepth*>>& layerNodes, const map<MTnode_withmaxdepth*, int>& nodeToLayerId, int treeIndex) {
    // Create a separate leaf directory for each tree
    string treeFolder = "trees_" + to_string(treeIndex);
    string leafFolder = treeFolder + "/leaf_layer";
    system(("mkdir -p " + leafFolder).c_str());
    
    int leafNodeId = 0;
    // Traverse all layers and find leaf nodes
    for (const auto& [layer, nodes] : layerNodes) {
        for (int i = 0; i < nodes.size(); i++) {
            MTnode_withmaxdepth* node = nodes[i];

            if (node->isLeaf) {
                // Output leaf node rules
                string filename = leafFolder + "/" + to_string(leafNodeId) + ".txt";
                ofstream outFile(filename);

                if (outFile.is_open()) {
                    // First line: number of rules
                    outFile << node->rules.size() << endl;

                    // If there are rules, output each rule
                    for (int ruleIndex = 0; ruleIndex < node->rules.size(); ruleIndex++) {
                        const Rule& rule = node->rules[ruleIndex];

                        outFile << ruleIndex << " 0 " << rule.range[0][0] << endl;  // src IP lower bound
                        outFile << ruleIndex << " 1 " << rule.prefix_length[0] << endl;  // src IP prefix length
                        outFile << ruleIndex << " 2 " << rule.range[1][0] << endl;  // dst IP lower bound
                        outFile << ruleIndex << " 3 " << rule.prefix_length[1] << endl;  // dst IP prefix length
                        outFile << ruleIndex << " 4 " << rule.range[2][0] << endl;  // src port lower bound
                        outFile << ruleIndex << " 5 " << rule.range[2][1] << endl;  // src port upper bound
                        outFile << ruleIndex << " 6 " << rule.range[3][0] << endl;  // dst port lower bound
                        outFile << ruleIndex << " 7 " << rule.range[3][1] << endl;  // dst port upper bound
                        outFile << ruleIndex << " 8 " << rule.range[4][0] << endl;  // protocol value
                        outFile << ruleIndex << " 9 " << (rule.range[4][1] == rule.range[4][0] ? 0xFF : 0) << endl;  // protocol mask
                    }
                    outFile.close();
                }
                leafNodeId++;
            }
        }
    }

    // Write the number of leaves into rules_{treeIndex}/count.txt
    string countFile = treeFolder + "/leaf_node_count.txt";
    ofstream countOut(countFile);
    if (countOut.is_open()) {
        countOut << leafNodeId << endl;
        countOut.close();
    }
}


void MegaTree_withmaxdepth::DeleteRule(const Rule &rule) {
    for (int t = 0; t < (int)roots.size(); ++t) {
        MTnode_withmaxdepth* root = roots[t];
        if (!root) continue;
        MTnode_withmaxdepth* leaf = FindLeafForRule(root, rule);
        if (!leaf) continue;

        auto &lv = leaf->rules;
        auto it = std::find_if(lv.begin(), lv.end(), [&](const Rule& r){ return r.id == rule.id; });
        if (it == lv.end()) continue;

        lv.erase(it);
        root->nRules = std::max(0, root->nRules - 1);

        updateLog.emplace_back(t, leaf->leafIndex, "delete", rule.id, leaf->rules);
        return;
    }
}


void MegaTree_withmaxdepth::InsertRule(const Rule &rule) {
    for (int t = 0; t < (int)roots.size(); ++t) {
        MTnode_withmaxdepth* root = roots[t];
        if (!root) continue;
        MTnode_withmaxdepth* leaf = FindLeafForRule(root, rule);
        if (!leaf) continue;

        if ((int)leaf->rules.size() < binth) {
            leaf->rules.push_back(rule);
            root->nRules += 1;
            root->rules.push_back(rule);

            // Record this update in the log, including the leaf’s current rule set
            updateLog.emplace_back(t, leaf->leafIndex, "insert", rule.id, leaf->rules);
            return;
        }
    }

    std::vector<Rule> single{rule};
    std::vector<Rule> tmp;
    MTnode_withmaxdepth* newRoot = ConstructMegaTree(single, tmp);
    newRoot->rules = single;
    newRoot->nRules = 1;
    roots.push_back(newRoot);

    int t = (int)roots.size() - 1;
    // Record this update in the log, including the leaf’s current rule set
    updateLog.emplace_back(t, newRoot->leafIndex, "insert", rule.id, newRoot->rules);
}


void MegaTree_withmaxdepth::PrintUpdateLog(const string& filename) {
    ofstream outFile(filename);
    if (!outFile.is_open()) {
        printf("Error: Cannot open file %s for writing\n", filename.c_str());
        return;
    }
    
    outFile << "# FPGA Hardware Update Log\n";
    outFile << "# Format: TreeIndex LeafIndex Operation RuleId\n";
    outFile << "# Followed by leaf node rules in FPGA RAM format\n";
    outFile << "# Total updates: " << updateLog.size() << "\n\n";
    
    for (const auto& info : updateLog) {
        outFile << "UPDATE TreeIndex=" << info.treeIndex << " LeafIndex=" << info.leafIndex << " " 
                << "Operation=" << info.operation << " RuleId=" << info.ruleId << "\n";
        
        outFile << info.leafRules.size() << "\n";
        for (int ruleIndex = 0; ruleIndex < (int)info.leafRules.size(); ++ruleIndex) {
            const Rule& rule = info.leafRules[ruleIndex];
            outFile << ruleIndex << " 0 " << rule.range[0][0] << "\n";                 // src IP low
            outFile << ruleIndex << " 1 " << rule.prefix_length[0] << "\n";            // src IP prefix len
            outFile << ruleIndex << " 2 " << rule.range[1][0] << "\n";                 // dst IP low
            outFile << ruleIndex << " 3 " << rule.prefix_length[1] << "\n";            // dst IP prefix len
            outFile << ruleIndex << " 4 " << rule.range[2][0] << "\n";                 // src port low
            outFile << ruleIndex << " 5 " << rule.range[2][1] << "\n";                 // src port high
            outFile << ruleIndex << " 6 " << rule.range[3][0] << "\n";                 // dst port low
            outFile << ruleIndex << " 7 " << rule.range[3][1] << "\n";                 // dst port high
            outFile << ruleIndex << " 8 " << rule.range[4][0] << "\n";                 // proto value
            outFile << ruleIndex << " 9 " << (rule.range[4][1] == rule.range[4][0] ? 0xFF : 0) << "\n"; // proto mask
        }
        outFile << "\n"; 
    }
    
    outFile.close();
    printf("FPGA update log written to %s (%zu operations)\n", filename.c_str(), updateLog.size());
}

