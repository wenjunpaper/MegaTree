#include <vector>
#include <fstream>
#include <string>
#include "../ElementaryClasses.h"


using namespace std;
struct MTnode_withmaxdepth {
    uint32_t dim, depth, threshold;
    bool isLeaf;
    vector<MTnode_withmaxdepth*> children;
    int nRules;
    vector<Rule> rules;
    int maxPri;
    int leafIndex; 

    // Constructors
    MTnode_withmaxdepth() {
        dim = 0;
        depth = 0;
        isLeaf = false;
        children.resize(2, nullptr);
        nRules = 0;
        maxPri = 0;
        leafIndex = -1; 
    }

    MTnode_withmaxdepth(const vector<Rule> &r) {
        rules = r;
        isLeaf = false;
        children.resize(2, nullptr);
        nRules = r.size();
        depth = 0;  
        leafIndex = -1;

        if (!r.empty()) {
            maxPri = r[0].priority;
        }
    }

    MTnode_withmaxdepth (int _dim, int _depth, int thre, bool leaf, const vector<Rule> &r) {
        dim = _dim;
        depth = _depth;
        isLeaf = leaf;
        rules = r;
        children.resize(2, nullptr);
        nRules = int(rules.size());
        threshold = thre;
        leafIndex = -1;
    }
};


struct UpdateInfo {
    int treeIndex;
    int leafIndex;
    string operation;  // "insert" 或 "delete"
    int ruleId;
    vector<Rule> leafRules; 
    
    UpdateInfo(int tree, int leaf, const string& op, int id, const vector<Rule>& rules) 
        : treeIndex(tree), leafIndex(leaf), operation(op), ruleId(id), leafRules(rules) {}
};



using namespace std;
class MegaTree_withmaxdepth : public PacketClassifier {
public:
    MegaTree_withmaxdepth();
    MegaTree_withmaxdepth(int md, int b);
    virtual void ConstructClassifier(const vector<Rule> &rules);
    virtual int ClassifyAPacket(const Packet &packet);
    virtual int ClassifyAPacket(const Packet &packet, uint64_t &Query);
    virtual void DeleteRule(const Rule &rule);
    virtual void InsertRule(const Rule &rule);
    virtual Memory MemSizeBytes() const;
    virtual int MemoryAccess() const;
    virtual size_t NumTables() const;
    virtual size_t RulesInTable(size_t tableIndex) const;

    virtual string funName() {
        return "MegaTree_withmaxdepth";
    }

    virtual void printInfo(std::ofstream &fout) {
        fout << roots.size() << ",";
        for (size_t i = 0; i < roots.size(); i ++) {
            fout << roots[i]->nRules << ",";
        }
    }
    
    void prints() const {
        printf("\tRoots: %zu\n", roots.size());
        printf("\tMax depth: %d\n", maxDepth);
        printf("\tBucket threshold: %d\n", binth);
    }

    MTnode_withmaxdepth* ConstructMegaTree(const vector<Rule> &rules, vector<Rule> &res);
    void OutputTreeLayers();

    void PrintUpdateLog(const string& filename = "update_log.txt");


private:
    int maxDepth;
    int binth;
    vector<MTnode_withmaxdepth*> roots;


    vector<UpdateInfo> updateLog;
    // Output layered information functions
    void OutputLeafNodes(const map<int, vector<MTnode_withmaxdepth*>>& layerNodes, const map<MTnode_withmaxdepth*, int>& nodeToLayerId, int treeIndex);
    Memory calculateNodeMemory(const MTnode_withmaxdepth* node) const;
         
};

