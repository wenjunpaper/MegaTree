#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <list>
#include <sys/time.h>
#include <string.h>
#include "MegaTurbo_Trees/MegaTree.h"


using namespace std;

const char* rulesFile = "./fw1_megaflow_100k.rules";          // ruleset file
const char* traceFile = "./fw1_packets_100k.trace";           // trace file 
FILE *fpr = fopen(rulesFile, "r");
FILE *fpt = fopen(traceFile, "r");
int classificationFlag = 1; //0:!run classification; 1:run classification 
int updateFlag = 1; //0:!run update; 1:run update (rand_update[MAXRULES]: ~half insert & half delete)


int maxDepth = 12;     // depth parameter
int bucketSize = 8;    // leaf threashold
int rand_update[MAXRULES]; //random generate rule id


/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  loadrule(FILE *fp)
 *  Description:  load rules from rule file
 * =====================================================================================
 */
vector<Rule> loadrule(FILE *fp) {
    unsigned sip1, sip2, sip3, sip4, smask;
    unsigned dip1, dip2, dip3, dip4, dmask;
    unsigned sport1, sport2;
    unsigned dport1, dport2;
    unsigned protocal, protocol_mask;
    unsigned ht, htmask;
    int number_rule = 0; //number of rules

    vector<Rule> rule;

    while (1) {
        Rule r;
        std::array<Point, 2> points;
        if (fscanf(fp, "@%d.%d.%d.%d/%d\t%d.%d.%d.%d/%d\t%d : %d\t%d : %d\t%x/%x\t%x/%x\n",
                   &sip1, &sip2, &sip3, &sip4, &smask, &dip1, &dip2, &dip3, &dip4, &dmask, &sport1, &sport2,
                   &dport1, &dport2, &protocal, &protocol_mask, &ht, &htmask) != 18)
            break;

        if (smask == 0) {
            points[0] = 0;
            points[1] = 0xFFFFFFFF;
        } else if (smask > 0 && smask <= 32) {
            uint32_t ip = (sip1 << 24) | (sip2 << 16) | (sip3 << 8) | sip4;
            uint32_t mask = (smask == 32) ? 0xFFFFFFFF : (0xFFFFFFFF << (32 - smask));
            points[0] = ip & mask;
            points[1] = points[0] | (~mask);
        } else {
            printf("Src IP length exceeds 32\n");
            exit(-1);
        }
        r.range[0] = points;

        if (dmask == 0) {
            points[0] = 0;
            points[1] = 0xFFFFFFFF;
        } else if (dmask > 0 && dmask <= 32) {
            uint32_t ip = (dip1 << 24) | (dip2 << 16) | (dip3 << 8) | dip4;
            uint32_t mask = (dmask == 32) ? 0xFFFFFFFF : (0xFFFFFFFF << (32 - dmask));
            points[0] = ip & mask;
            points[1] = points[0] | (~mask);
        } else {
            printf("Dest IP length exceeds 32\n");
            exit(-1);
        }
        r.range[1] = points;

        points[0] = sport1;
        points[1] = sport2;
        r.range[2] = points;

        points[0] = dport1;
        points[1] = dport2;
        r.range[3] = points;

        for (int i = 15; i >= 0; i--) {
            unsigned int Bit = 1 << i;
            unsigned int sp = sport1 ^ sport2;
            if (sp & Bit) {
                break;
            }
            r.prefix_length[2]++;
        }

        for (int i = 15; i >= 0; i--) {
            unsigned int Bit = 1 << i;
            unsigned int dp = dport1 ^ dport2;
            if (dp & Bit) {
                break;
            }
            r.prefix_length[3]++;
        }

        if (protocol_mask == 0xFF) {
            points[0] = protocal;
            points[1] = protocal;
            r.prefix_length[4] = 8;
        } else if (protocol_mask == 0) {
            points[0] = 0;
            points[1] = 0xFF;
        } else {
            printf("Protocol mask error\n");
            exit(-1);
        }
        r.range[4] = points;

        r.prefix_length[0] = smask;
        r.prefix_length[1] = dmask;
        r.id = number_rule;

        rule.push_back(r);
        number_rule++;
    }

    int max_pri = number_rule - 1;
    for (int i = 0; i < number_rule; i++) {
        rule[i].priority = max_pri - i;
        /*printf("%u: %u:%u %u:%u %u:%u %u:%u %u:%u %d\n", i,
          rule[i].range[0][0], rule[i].range[0][1],
          rule[i].range[1][0], rule[i].range[1][1],
          rule[i].range[2][0], rule[i].range[2][1],
          rule[i].range[3][0], rule[i].range[3][1],
          rule[i].range[4][0], rule[i].range[4][1],
          rule[i].priority);*/
    }
    return rule;
}

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  loadpacket(FILE *fp)
 *  Description:  load packets from trace file generated from NuevoMatch[USENIX NSDI]
 * =====================================================================================
 */
std::vector<Packet> loadpacket(FILE *fp) {
    unsigned int header[MAXDIMENSIONS];
    unsigned int proto_mask, fid;
    int number_pkt = 0; //number of packets
    std::vector<Packet> packets;
    while (1) {
        if (fscanf(fp, "%u %u %d %d %d %u %d\n", &header[0], &header[1], &header[2], &header[3], &header[4],
                   &proto_mask, &fid) == Null)
            break;
        Packet p;
        p.push_back(header[0]);
        p.push_back(header[1]);
        p.push_back(header[2]);
        p.push_back(header[3]);
        p.push_back(header[4]);
        p.push_back(fid);

        packets.push_back(p);
        number_pkt++;
    }

    /*printf("the number of packets = %d\n", number_pkt);
    for(int i=0;i<number_pkt;i++){
        printf("%u: %u %u %u %u %u %u\n", i,
               packets[i][0],
               packets[i][1],
               packets[i][2],
               packets[i][3],
               packets[i][4],
               packets[i][5]);
			   }*/

    return packets;
}

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  parseargs(int argc, char *argv[])
 *  Description:  Parse arguments from the console
 * =====================================================================================
 */
void parseargs(int argc, char *argv[]) {
    int c;
    bool ok = 1;
    while ((c = getopt(argc, argv, "b:d:r:e:c:u:h")) != -1) {
        switch (c) {
            case 'b':  //bucketsize of leaf node
                bucketSize = atoi(optarg);
                break;
            case 'd':  //maxDepth for tree construction
                maxDepth = atoi(optarg);
                break;                
            case 'r':  //rule set
                rulesFile = optarg;
                fpr = fopen(optarg, "r");
                break;
            case 'e':  //trace packets for simulations
                traceFile = optarg;
                fpt = fopen(optarg, "r");
                break;
            case 'c':  //classification simulation				
                classificationFlag = atoi(optarg);
                break;
            case 'u':  //update simulation
                updateFlag = atoi(optarg);
                break;
            case 'h': //help
                printf("./main [-b bucketSize][-d maxDepth][-r ruleset][-e trace][-c (1:classification)][-u (1:update)]\n");
                printf("e.g., ./main -b 8 -d 12 -r ./fw1_megaflow_100k.rules -e ./fw1_packets_100k.trace -c 1 -u 1\n");
                exit(1);
                break;
            default:
                ok = 0;
        }
    }
}

/*
 * ===  FUNCTION  ======================================================================
 *         Name:  main function for {MegaTree}
 *  Description:  loadrule->construction-->classification-->update
 * =====================================================================================
 */
int main(int argc, char *argv[]) {
    parseargs(argc, argv);
    system("rm -rf trees_*");  // Delete all tree folders 
    system("rm -f update_log.txt");  // Delete update log file
    printf("Cleaned previous output files\n");

    vector<Rule> rule;
    vector<Packet> packets;
    int number_rule = 0;

    std::chrono::time_point<std::chrono::steady_clock> start, end;
    std::chrono::duration<double> elapsed_seconds;
    std::chrono::duration<double, std::milli> elapsed_milliseconds;

    if (fpr != nullptr) {
        rule = loadrule(fpr);
        number_rule = int(rule.size());
        printf("Rules file: %s\n", rulesFile);
        printf("Trace file: %s\n", traceFile);
        printf("The number of rules = %d\n", number_rule);
        printf("**************** Construction ****************\n");

//---MegaTree with max depth---Construction---
        printf("MegaTree with max depth\n");
        MegaTree_withmaxdepth MT(maxDepth, bucketSize);
        start = std::chrono::steady_clock::now(); 
        MT.ConstructClassifier(rule);
        end = std::chrono::steady_clock::now();
        elapsed_milliseconds = end - start;
        MT.OutputTreeLayers();
        MT.prints();
        printf("\tConstruction time: %f ms\n", elapsed_milliseconds.count());
        printf("\tTotal memory consumption: %f(KB) \n", double(MT.MemSizeBytes()) / 1024);
        printf("\tAverage memory consumption: %f Byte/rule \n", double(MT.MemSizeBytes()) / number_rule);


        if (classificationFlag != NULL) {
            printf("\n**************** Classification ****************\n");
            packets = loadpacket(fpt);
            int number_pkt = packets.size();
            printf("\tThe number of packet in the trace file = %d\n", number_pkt);
            const int trials = 10; //run 10 times circularly
            printf("\tTotal packets (run %d times circularly): %d\n", trials, packets.size() * trials);
            int match_miss = 0;
            int matchid[number_pkt];
//---MegaTree with max depth---Classification---
            printf("MegaTree with max depth\n");
            std::chrono::duration<double> sum_time_MT(0);
            match_miss = 0;
            for (int t = 0; t < trials; t++) {
                start = std::chrono::steady_clock::now();
                for (int j = 0; j < number_pkt; j++) {
                    matchid[j] = number_rule - 1 - MT.ClassifyAPacket(packets[j]);
                }
                end = std::chrono::steady_clock::now();
                elapsed_seconds = end - start;
                sum_time_MT += elapsed_seconds;
                for (int j = 0; j < number_pkt; j++) {
                    if (matchid[j] == -1 || packets[j][5] != matchid[j]) {
                        match_miss++;
                    }
                }
            }
            printf("\t%d packets are classified, %d of them are misclassified\n", number_pkt * trials, match_miss);
            printf("\tTotal classification time: %f s\n", sum_time_MT.count() / trials);
            printf("\tAverage classification time: %f us\n", sum_time_MT.count() * 1e6 / (trials * packets.size()));
            printf("\tThroughput: %f Mpps\n", 1 / (sum_time_MT.count() * 1e6 / (trials * packets.size())));
        }


        if (updateFlag == 1) {
            printf("\n**************** Update ****************\n");
            srand((unsigned) time(NULL));
            for (int ra = 0; ra < MAXRULES; ra++) { //1000000
                rand_update[ra] = rand() % 2; //0:insert 1:delete
            }
            int insert_num = 0, delete_num = 0;
            int number_update = min((int)(number_rule * 0.2), MAXRULES);
            printf("\tThe number of updated rules = %d\n", number_update);

//---MegaTree with max depth---Update---
            printf("MegaTree with max depth\n");
            insert_num = 0, delete_num = 0;
            start = std::chrono::steady_clock::now();
            for (int ra = 0; ra < number_update; ra++) {
                if (rand_update[ra] == 0) {//0:insert
                    MT.InsertRule(rule[ra]);
                    insert_num++;
                } else {//1:delete
                    MT.DeleteRule(rule[ra]);
                    delete_num++;
                }
            }
            end = std::chrono::steady_clock::now();
            elapsed_seconds = end - start;
            
            MT.PrintUpdateLog("update_log.txt");
            printf("\t%d rules update: insert_num = %d delete_num = %d\n", number_update, insert_num, delete_num);
            printf("\tTotal update time: %f s\n", elapsed_seconds.count());
            printf("\tAverage update time: %f us\n", elapsed_seconds.count() * 1e6 / number_update);
            printf("\tAverage update throughput: %f MUPS\n", 1 / (elapsed_seconds.count() * 1e6 / number_update));
        }
    }

    printf("\n**************** Over ****************\n");
    return 0;
}
